module.exports = {
    MONGOURI: process.env.MONGOURI,
    JWT_SECRET: process.env.JWT_SECRET,
    SENDGRID_APIKEY: process.env.SENDGRID_APIKEY,
    EMAIL: process.env.EMAIL,
    EMAILURL: process.env.EMAILURL
};